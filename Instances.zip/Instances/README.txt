Instance (Vector):
u_*_*.0 

The first 16 values correspond to the estimated execution time (p_ij) of the first job on the 16 machines, the next 16 values correspond to the p_ij of the second job i on the 16 machines (j) and so on.

Instance (matrix) :
u_*_*_tasks_machines.text

Each row represent the 16 values of the p_ij of each job on the machines

0: p_11, p_12, p_13…., p_116 
1: p_21, p_22, p_23,…., p_216
.
.
.
511: p_5111, p_5112, p_5113, …., p_51116